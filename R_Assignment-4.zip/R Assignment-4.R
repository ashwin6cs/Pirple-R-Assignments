
genre <- function()
{
  return("Jazz")
}

artist <- function()
{
  return("Dave Brubeck")
}

year <- function()
{
  return(1920)
}
